

<?php $__env->startSection('title','Cadastro'); ?>

<?php $__env->startSection('content'); ?>
<h2>OS's Cadastradas</h2>
<div class="container-fluid">
    <table class="table table-striped" id='tb_gestao'>
        <thead>
            <tr>
                <th>ID</th>
                <th>Breve Descrição</th>
                <th>Entidade</th>
                <th>Localização</th>
                <th>Status Orig.</th>
                <th>Descrição</th>
                <th>Categoria</th>
                <th>Solução</th>
                <th>Prioridade</th>
                <th>Requerente</th>
                <th>Últ. Atualiz.</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody class='table-group-divider'>
            <?php $__currentLoopData = $os_ufes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $os): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($os->id_ufes); ?></td>
                <td><?php echo e($os->breve_descricao); ?></td>
                <td><?php echo e($os->entidade); ?></td>
                <td><?php echo e($os->localizacao); ?></td>
                <td><?php echo e($os->status_ufes); ?></td>
                <td><?php echo e($os->descricao); ?></td>
                <td><?php echo e($os->categoria); ?></td>
                <td><?php echo e($os->solucao); ?></td>
                <td><?php echo e($os->prioridade); ?></td>
                <td><?php echo e($os->requerente); ?></td>
                <td><?php echo e($os->ult_atualizacao); ?></td>

                <td>

                    <form action="<?php echo e(route('os_gestao.destroy', $os->id)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger">Excluir</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<script>
    $(document).ready(function() {
        // Verifica se o DataTable já está inicializado
        if ($.fn.DataTable.isDataTable("#tb_gestao")) {
            // Destroi o DataTable existente antes de re-inicializá-lo
            $("#tb_gestao").DataTable().clear().destroy();
        }

        // Inicializa o DataTable
        $("#tb_gestao").DataTable({
            paging: true, // Ativar paginação
            searching: true, // Ativar pesquisa
            //order: [[0, "desc"]],
            language: {
                url: "//cdn.datatables.net/plug-ins/2.0.8/i18n/pt-BR.json",
            },
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\geros\resources\views/os_gestao/index.blade.php ENDPATH**/ ?>