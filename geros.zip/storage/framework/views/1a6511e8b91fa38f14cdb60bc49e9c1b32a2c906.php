<!-- views/import/index.blade.php -->

<!-- Exibir mensagens de sucesso ou erro -->
<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>

<!-- Formulário -->
<form action="<?php echo e(route('import')); ?>" method="POST" enctype="multipart/form-data" id="importForm">
    <?php echo csrf_field(); ?>
    <div class="form-group">
        <label for="file">Escolher arquivo</label>
        <input type="file" class="form-control" name="file" required>
    </div>
    <button type="submit" class="btn btn-primary">Importar</button>
</form>

<!-- Loader -->
<!-- Loader estilizado -->
<div id="loader" style="display:none; text-align: center; margin-top: 20px;">
    <div class="spinner-border" role="status">
        <span class="sr-only">Processando...</span>
    </div>
    <p>Processando, por favor aguarde...</p>
</div>




<script>
document.getElementById('importForm').addEventListener('submit', function() {
    // Mostrar o loader
    document.getElementById('loader').style.display = 'block';
    // Esconder o formulário
    this.style.display = 'none';
});
</script>
<?php /**PATH C:\xampp\htdocs\geros\resources\views/import/index.blade.php ENDPATH**/ ?>