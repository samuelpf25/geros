@extends('layouts.main')

@section('title','Cadastro')

@section('content')
<h2>OS's Cadastradas</h2>
<div class="container-fluid">
    <table class="table table-striped" id='tb_gestao'>
        <thead>
            <tr>
                <th>ID</th>
                <th>Breve Descrição</th>
                <th>Entidade</th>
                <th>Localização</th>
                <th>Status Orig.</th>
                <th>Descrição</th>
                <th>Categoria</th>
                <th>Solução</th>
                <th>Prioridade</th>
                <th>Requerente</th>
                <th>Últ. Atualiz.</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody class='table-group-divider'>
            @foreach($os_ufes as $os)
            <tr>
                <td>{{ $os->id_ufes }}</td>
                <td>{{ $os->breve_descricao }}</td>
                <td>{{ $os->entidade }}</td>
                <td>{{ $os->localizacao }}</td>
                <td>{{ $os->status_ufes }}</td>
                <td>{{ $os->descricao }}</td>
                <td>{{ $os->categoria }}</td>
                <td>{{ $os->solucao }}</td>
                <td>{{ $os->prioridade }}</td>
                <td>{{ $os->requerente }}</td>
                <td>{{ $os->ult_atualizacao }}</td>

                <td>

                    <form action="{{ route('os_gestao.destroy', $os->id) }}" method="POST" style="display:inline;">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-danger">Excluir</button>
                    </form>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
<script>
    $(document).ready(function() {
        // Verifica se o DataTable já está inicializado
        if ($.fn.DataTable.isDataTable("#tb_gestao")) {
            // Destroi o DataTable existente antes de re-inicializá-lo
            $("#tb_gestao").DataTable().clear().destroy();
        }

        // Inicializa o DataTable
        $("#tb_gestao").DataTable({
            paging: true, // Ativar paginação
            searching: true, // Ativar pesquisa
            //order: [[0, "desc"]],
            language: {
                url: "//cdn.datatables.net/plug-ins/2.0.8/i18n/pt-BR.json",
            },
        });
    });
</script>
@endsection