<?php

namespace App\Http\Controllers;

use App\Models\Usuarios;
use Illuminate\Http\Request;

class UsuariosController extends Controller
{
   /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $usuarios = Usuarios::all();
        return view('usuarios.listar_usuarios', compact('usuarios'));
    }

    public function create()
    {
        //$igrejas = Igreja::all();
        return view('usuarios.create_usuarios'); //, compact('igrejas')
    }

    public function store(Request $request)
    {
        try {
            $usuario = new Usuarios();
            $usuario->nome = $request->nome;
            $usuario->endereco = $request->endereco;
            $usuario->telefone = $request->telefone;
            $usuario->dataNascimento = $request->dataNascimento;

            $imageName = time() . '.' . $request->foto->extension();
            $request->foto->move(public_path('img/fotos'), $imageName);
            $usuario->foto = $imageName;

            $usuario->estadoCivil = $request->estadoCivil;
            $usuario->sexo = $request->sexo;
            $usuario->email = $request->email;
            $usuario->ativo = $request->ativo;
            $usuario->login = $request->login;
            $usuario->senha = $request->senha;
            $usuario->igreja_id = $request->igreja_id;
            $usuario->save();

            return redirect()->route('usuarios.index')->with('success', 'Usuarios cadastrada com sucesso!');
        } catch (\Exception $e) {
            return redirect()->route('usuarios.index')->with('error', 'Falha ao cadastrar pessoa. ' . $e->getMessage());
        }
    }

    public function show($id)
    {
        $usuario = Usuarios::findOrFail($id);
        return view('usuarios.show', compact('Usuarios'));
    }

    public function edit($id)
    {
        $usuario = Usuarios::findOrFail($id);
        return view('usuarios.edit', compact('Usuarios'));
    }

    public function update(Request $request, $id)
    {
        try {
            $usuario = Usuarios::findOrFail($id);
            $usuario->nome = $request->nome;
            $usuario->endereco = $request->endereco;
            $usuario->telefone = $request->telefone;
            $usuario->dataNascimento = $request->dataNascimento;
            if ($request->hasFile('foto') && $request->file('foto')->isValid()) {
                $imageName = time() . '.' . $request->foto->extension();
                $request->foto->move(public_path('img/fotos'), $imageName);
                $usuario->foto = $imageName;
            }
            $usuario->estadoCivil = $request->estadoCivil;
            $usuario->sexo = $request->sexo;
            $usuario->email = $request->email;
            $usuario->ativo = $request->ativo;
            $usuario->login = $request->login;
            $usuario->senha = $request->senha;
            $usuario->igreja_id = $request->igreja_id;
            $usuario->save();

            return redirect()->route('usuarios.index')->with('success', 'Usuarios atualizada com sucesso!');
        } catch (\Exception $e) {
            return redirect()->route('usuarios.index')->with('error', 'Falha ao atualizar pessoa. ' . $e->getMessage());
        }
    }

    public function destroy($id)
    {
        $usuario = Usuarios::findOrFail($id);
        $usuario->delete();

        return redirect()->route('usuarios.index');
    }
}
