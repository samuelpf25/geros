<?php

namespace App\Http\Controllers;

use App\Models\Os_gestao;
use App\Models\Os_ufes;
use Illuminate\Http\Request;

class Os_gestaoController extends Controller
{
    public function index()
    {
        $os_gestao = Os_gestao::all();
        $os_ufes = Os_ufes::all();
        return view('os_gestao.index', compact('os_gestao','os_ufes'));
    }

    public function create()
    {
        return view('os_gestao.create');
    }

    public function store(Request $request)
    {
        $post = new Os_gestao();
        $post->title = $request->title;
        $post->content = $request->content;
        $post->save();

        return redirect()->route('os_gestao.index');
    }

    public function show($id)
    {
        $post = Os_gestao::findOrFail($id);
        return view('os_gestao.show', compact('post'));
    }

    public function edit($id)
    {
        $post = Os_gestao::findOrFail($id);
        return view('os_gestao.edit', compact('post'));
    }

    public function update(Request $request, $id)
    {
        $post = Os_gestao::findOrFail($id);
        $post->title = $request->title;
        $post->content = $request->content;
        $post->save();

        return redirect()->route('os_gestao.index');
    }

    public function destroy($id)
    {
        $post = Os_gestao::findOrFail($id);
        $post->delete();

        return redirect()->route('os_gestao.index');
    }

}
