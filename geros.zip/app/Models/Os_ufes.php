<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Os_ufes extends Model
{
    protected $table = 'os_ufes';
    use HasFactory;
}
