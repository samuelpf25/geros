<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Os_gestao extends Model
{
    protected $table = 'os_gestao';
    use HasFactory;

}
